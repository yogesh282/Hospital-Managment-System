package hospital.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import hospital.model.Patient;
import hospital.repo.PatientRepository;
import hospital.service.IPatientService;

@Service
public class PatientServiceImpl implements IPatientService {

	@Autowired
	private PatientRepository repo;
	
	@Override
	public Integer savePatient(Patient s) {
		s = repo.save(s);
		return s.getId();
	}

	@Override
	public void updatePatient(Patient s) {
		repo.save(s);
	}

	@Override
	public void deletePatient(Integer id) {
		repo.deleteById(id);
	}

	@Override
	public Optional<Patient> getOnePatient(Integer id) {
		return repo.findById(id);
	}

	@Override
	public List<Patient> getAllPatients() {
		return repo.findAll();
	}

	@Override
	public boolean isPatientExist(Integer id) {
		return repo.existsById(id);
	}

}














