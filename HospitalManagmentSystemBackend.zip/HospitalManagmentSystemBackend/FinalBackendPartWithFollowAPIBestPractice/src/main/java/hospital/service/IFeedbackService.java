package hospital.service;

import java.util.List;
import java.util.Optional;

import hospital.model.Feedback;

public interface IFeedbackService {

	
	Integer saveFeedback(Feedback a);
	void updateFeedback(Feedback a);
	
	void deleteFeedback(Integer a);
	
	Optional<Feedback> getOneFeedback(Integer id);
	List<Feedback> getAllFeedbacks();
	
	boolean isFeedbackExist(Integer id);
	
}
