package hospital.service.impl;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import hospital.model.Feedback;
import hospital.repo.FeedbackRepository;
import hospital.service.IFeedbackService;


@Service
public class FeedbackServiceImpl implements IFeedbackService {

	
	@Autowired
	private FeedbackRepository repo;
	
	@Override 
	public Integer saveFeedback(Feedback a) {
		a= repo.save(a);
		return a.getId();		
	}
	
	@Override
	public void updateFeedback(Feedback a) {
		repo.save(a);
	}
	
	@Override
	public void deleteFeedback(Integer id) {
		repo.deleteById(id);
	}
	
	@Override
	public Optional<Feedback> getOneFeedback(Integer id) {
		return repo.findById(id);
	}
	
	@Override 
	public List<Feedback> getAllFeedbacks() {
		return repo.findAll();
	}
	
	@Override 
	public boolean isFeedbackExist(Integer id) {
		return repo.existsById(id);
	}
	

}
