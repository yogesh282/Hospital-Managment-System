package hospital.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import hospital.model.Appointment;
import hospital.repo.AppointmentRepository;
import hospital.service.IAppointmentService;


@Service
public class AppointmentServiceImpl implements IAppointmentService {

	
	@Autowired
	private AppointmentRepository repo;
	
	@Override 
	public Integer saveAppointment(Appointment a) {
		a= repo.save(a);
		return a.getId();		
	}
	
	@Override
	public void updateAppointment(Appointment a) {
		repo.save(a);
	}
	
	@Override
	public void deleteAppointment(Integer id) {
		repo.deleteById(id);
	}
	
	@Override
	public Optional<Appointment> getOneAppointment(Integer id) {
		return repo.findById(id);
	}
	
	@Override 
	public List<Appointment> getAllAppointments() {
		return repo.findAll();
	}
	
	@Override 
	public boolean isAppointmentExist(Integer id) {
		return repo.existsById(id);
	}
	

}