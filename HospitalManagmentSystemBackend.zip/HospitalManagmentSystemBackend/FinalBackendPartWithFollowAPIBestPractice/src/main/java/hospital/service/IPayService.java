package hospital.service;

import java.util.List;
import java.util.Optional;

import hospital.model.Pay;

public interface IPayService {

	
	Integer savePay(Pay a);
	void updatePay(Pay a);
	
	void deletePay(Integer a);
	
	Optional<Pay> getOnePay(Integer id);
	List<Pay> getAllPays();
	
	boolean isPayExist(Integer id);
	
}
