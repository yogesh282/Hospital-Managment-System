package hospital.service;

import java.util.List;
import java.util.Optional;

import hospital.model.Patient;

public interface IPatientService {

	Integer savePatient(Patient s);
	void updatePatient(Patient s);
	
	void deletePatient(Integer id);

	Optional<Patient> getOnePatient(Integer id);
	List<Patient> getAllPatients();

	boolean isPatientExist(Integer id);
}

