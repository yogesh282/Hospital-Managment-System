package hospital.service;

import java.util.List;
import java.util.Optional;

import hospital.model.Doctor;

public interface IDoctorService {

	Integer saveDoctor(Doctor s);
	void updateDoctor(Doctor s);
	
	void deleteDoctor(Integer id);

	Optional<Doctor> getOneDoctor(Integer id);
	List<Doctor> getAllDoctors();

	boolean isDoctorExist(Integer id);
}

