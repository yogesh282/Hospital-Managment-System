package hospital.service.impl;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import hospital.model.Pay;
import hospital.repo.PayRepository;
import hospital.service.IPayService;


@Service
public class PayServiceImpl implements IPayService {

	
	@Autowired
	private PayRepository repo;
	
	@Override 
	public Integer savePay(Pay a) {
		a= repo.save(a);
		return a.getId();		
	}
	
	@Override
	public void updatePay(Pay a) {
		repo.save(a);
	}
	
	@Override
	public void deletePay(Integer id) {
		repo.deleteById(id);
	}
	
	@Override
	public Optional<Pay> getOnePay(Integer id) {
		return repo.findById(id);
	}
	
	@Override 
	public List<Pay> getAllPays() {
		return repo.findAll();
	}
	
	@Override 
	public boolean isPayExist(Integer id) {
		return repo.existsById(id);
	}
	

}
