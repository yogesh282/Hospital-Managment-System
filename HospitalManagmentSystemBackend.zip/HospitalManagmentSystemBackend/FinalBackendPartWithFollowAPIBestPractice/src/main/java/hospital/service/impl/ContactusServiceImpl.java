package hospital.service.impl;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import hospital.model.Contactus;
import hospital.repo.ContactusRepository;
import hospital.service.IContactusService;


@Service
public class ContactusServiceImpl implements IContactusService {

	
	@Autowired
	private ContactusRepository repo;
	
	@Override 
	public Integer saveContactus(Contactus a) {
		a= repo.save(a);
		return a.getId();		
	}
	
	@Override
	public void updateContactus(Contactus a) {
		repo.save(a);
	}
	
	@Override
	public void deleteContactus(Integer id) {
		repo.deleteById(id);
	}
	
	@Override
	public Optional<Contactus> getOneContactus(Integer id) {
		return repo.findById(id);
	}
	
	@Override 
	public List<Contactus> getAllContactuss() {
		return repo.findAll();
	}
	
	@Override 
	public boolean isContactusExist(Integer id) {
		return repo.existsById(id);
	}
	

}
