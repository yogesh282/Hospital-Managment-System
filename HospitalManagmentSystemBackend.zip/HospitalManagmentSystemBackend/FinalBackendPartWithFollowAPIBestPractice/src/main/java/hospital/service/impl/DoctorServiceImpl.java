package hospital.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import hospital.model.Doctor;
import hospital.repo.DoctorRepository;
import hospital.service.IDoctorService;

@Service
public class DoctorServiceImpl implements IDoctorService {

	@Autowired
	private DoctorRepository repo;
	
	@Override
	public Integer saveDoctor(Doctor s) {
		s = repo.save(s);
		return s.getId();
	}

	@Override
	public void updateDoctor(Doctor s) {
		repo.save(s);
	}

	@Override
	public void deleteDoctor(Integer id) {
		repo.deleteById(id);
	}

	@Override
	public Optional<Doctor> getOneDoctor(Integer id) {
		return repo.findById(id);
	}

	@Override
	public List<Doctor> getAllDoctors() {
		return repo.findAll();
	}

	@Override
	public boolean isDoctorExist(Integer id) {
		return repo.existsById(id);
	}

}






