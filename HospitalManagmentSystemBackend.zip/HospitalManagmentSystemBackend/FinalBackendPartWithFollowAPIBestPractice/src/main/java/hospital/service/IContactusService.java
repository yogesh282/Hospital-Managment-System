package hospital.service;

import java.util.List;
import java.util.Optional;

import hospital.model.Contactus;

public interface IContactusService {

	
	Integer saveContactus(Contactus a);
	void updateContactus(Contactus a);
	
	void deleteContactus(Integer a);
	
	Optional<Contactus> getOneContactus(Integer id);
	List<Contactus> getAllContactuss();
	
	boolean isContactusExist(Integer id);
	
}