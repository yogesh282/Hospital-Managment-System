package hospital.service;

import java.util.List;
import java.util.Optional;

import hospital.model.Appointment;

public interface IAppointmentService {

	
	Integer saveAppointment(Appointment a);
	void updateAppointment(Appointment a);
	
	void deleteAppointment(Integer a);
	
	Optional<Appointment> getOneAppointment(Integer id);
	List<Appointment> getAllAppointments();
	
	boolean isAppointmentExist(Integer id);
	
}