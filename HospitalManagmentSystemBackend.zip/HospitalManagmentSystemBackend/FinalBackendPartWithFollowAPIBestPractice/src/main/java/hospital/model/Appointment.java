package hospital.model;

import javax.persistence.Entity;
import javax.persistence.Table;



import javax.persistence.Id;
import javax.persistence.GeneratedValue;
import javax.persistence.Column;

@Entity
    @Table
	public class Appointment{
	
	@Id
	@GeneratedValue
	
	@Column
	private Integer Id;
	
	@Column
	private String DoctorName;
	
	@Column
	private String PatientName;
	
	@Column 
	private String Description;
	
	@Column
	private String Day;

	public Integer getId() {
		return Id;
	}

	public void setId(Integer id) {
		Id = id;
	}

	public String getDoctorName() {
		return DoctorName;
	}

	public void setDoctorName(String doctorName) {
		DoctorName = doctorName;
	}

	public String getPatientName() {
		return PatientName;
	}

	public void setPatientName(String patientName) {
		PatientName = patientName;
	}

	public String getDescription() {
		return Description;
	}

	public void setDescription(String description) {
		Description = description;
	}

	public String getDay() {
		return Day;
	}

	public void setDay(String day) {
		Day = day;
	}

	


	
}
