package hospital.model;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Id;
import javax.persistence.GeneratedValue;
import javax.persistence.Column;

@Entity
    @Table
	public class Pay{
	
	@Id
	@GeneratedValue
	
	@Column
	private Integer Id;
	
	@Column
	private String AdmitDate;
	
	@Column
	private String ReleaseDate;
	
	@Column 
	private String Name;
	
	@Column 
	private Double Mobile;
	
	@Column 
	private String Address;
	
	@Column 
	private String Symptoms;
	
	@Column 
	private Integer RoomCharge;
	
	@Column 
	private Integer DoctorFee;
	
	@Column 
	private Integer MedicineCost;
	
	@Column
	private String Message;

	public Integer getId() {
		return Id;
	}

	public void setId(Integer id) {
		Id = id;
	}

	public String getAdmitDate() {
		return AdmitDate;
	}

	public void setAdmitDate(String admitDate) {
		AdmitDate = admitDate;
	}

	public String getReleaseDate() {
		return ReleaseDate;
	}

	public void setReleaseDate(String releaseDate) {
		ReleaseDate = releaseDate;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public Double getMobile() {
		return Mobile;
	}

	public void setMobile(Double mobile) {
		Mobile = mobile;
	}

	public String getAddress() {
		return Address;
	}

	public void setAddress(String address) {
		Address = address;
	}

	public String getSymptoms() {
		return Symptoms;
	}

	public void setSymptoms(String symptoms) {
		Symptoms = symptoms;
	}

	public Integer getRoomCharge() {
		return RoomCharge;
	}

	public void setRoomCharge(Integer roomCharge) {
		RoomCharge = roomCharge;
	}

	public Integer getDoctorFee() {
		return DoctorFee;
	}

	public void setDoctorFee(Integer doctorFee) {
		DoctorFee = doctorFee;
	}

	public Integer getMedicineCost() {
		return MedicineCost;
	}

	public void setMedicineCost(Integer medicineCost) {
		MedicineCost = medicineCost;
	}

	public String getMessage() {
		return Message;
	}

	public void setMessage(String message) {
		Message = message;
	}

	

	
	
}
