
package hospital.util;

import org.springframework.stereotype.Component;


import hospital.model.Patient;

@Component
public class PatientUtil {
	public void mapToActualObject(Patient actual, Patient patient) {
		if(patient.getName()!=null)
			actual.setName(patient.getName());
		actual.setMobilenumber(patient.getMobilenumber());
		
		actual.setGender(patient.getGender());
		actual.setUsername(patient.getUsername());
		
		actual.setPassword(patient.getPassword());
		
		if(patient.getEmail()!=null)
			actual.setEmail(patient.getEmail());
		actual.setAddr(patient.getAddr());

}

}