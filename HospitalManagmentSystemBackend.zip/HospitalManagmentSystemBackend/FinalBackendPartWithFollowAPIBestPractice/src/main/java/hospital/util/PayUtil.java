package hospital.util;

import org.springframework.stereotype.Component;

import hospital.model.Pay;

@Component
public class PayUtil {
	
	public void mapToActualObject(Pay actual, Pay pay) {
		
		
		if(pay.getName()!=null)
			actual.setName(pay.getName());
		actual.setAddress(pay.getAddress());
		actual.setMobile(pay.getMobile());
		if(pay.getMessage()!=null)
			actual.setMessage(pay.getMessage());
		actual.setSymptoms(pay.getSymptoms());
	}
}
