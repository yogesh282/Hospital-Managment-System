package hospital.util;


import org.springframework.stereotype.Component;

import hospital.model.Appointment;

@Component
public class AppointmentUtil {
	
	public void mapToActualObject(Appointment actual, Appointment appointment) {
		
		if(appointment.getDoctorName()!=null)
			actual.setDoctorName(appointment.getDoctorName());
		actual.setPatientName(appointment.getPatientName());
		actual.setDay(appointment.getDay());
		if(appointment.getDescription()!=null)
			actual.setDescription(appointment.getDescription());
		actual.setPatientName(appointment.getPatientName());
	}
}


