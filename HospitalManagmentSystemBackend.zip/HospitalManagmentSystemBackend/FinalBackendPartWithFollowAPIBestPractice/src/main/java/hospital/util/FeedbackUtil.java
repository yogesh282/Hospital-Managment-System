package hospital.util;

import org.springframework.stereotype.Component;

import hospital.model.Feedback;

@Component
public class FeedbackUtil {
	
	public void mapToActualObject(Feedback actual, Feedback feedback) {
		
		if(feedback.getPatientName()!=null)
			actual.setPatientName(feedback.getPatientName());
		actual.setPhoneNumber(feedback.getPhoneNumber());
		actual.setEmail(feedback.getEmail());
		if(feedback.getComments()!=null)
			actual.setComments(feedback.getComments());
	}

}
