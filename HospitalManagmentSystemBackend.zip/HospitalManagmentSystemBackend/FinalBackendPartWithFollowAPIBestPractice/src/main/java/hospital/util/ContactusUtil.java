package hospital.util;


import org.springframework.stereotype.Component;

import hospital.model.Contactus;

@Component
public class ContactusUtil {
	
	public void mapToActualObject(Contactus actual, Contactus contactus) {
		
		
		if(contactus.getName()!=null)
			actual.setName(contactus.getName());
		actual.setEmail(contactus.getEmail());
		actual.setPhoneNumber(contactus.getPhoneNumber());
		if(contactus.getMessage()!=null)
			actual.setMessage(contactus.getMessage());
		actual.setEmail(contactus.getEmail());
	}
}