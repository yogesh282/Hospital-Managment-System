
package hospital.util;

import org.springframework.stereotype.Component;

import hospital.model.Doctor;


@Component
public class DoctorUtil {








	public void mapToActualObject(Doctor actual, Doctor doctor) {
		if(doctor.getName()!=null)
			actual.setName(doctor.getName());
		actual.setMobilenumber(doctor.getMobilenumber());
		actual.setGender(doctor.getGender());
		actual.setUsername(doctor.getUsername());
		
		actual.setPassword(doctor.getPassword());
		
		
		if(doctor.getEmail()!=null)
			actual.setEmail(doctor.getEmail());
		actual.setAddr(doctor.getAddr());
	}

}
