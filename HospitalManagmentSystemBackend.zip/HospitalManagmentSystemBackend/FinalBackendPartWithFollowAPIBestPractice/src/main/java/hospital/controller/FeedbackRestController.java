package hospital.controller;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import hospital.model.Feedback;
import hospital.service.IFeedbackService;
import hospital.util.FeedbackUtil;


/*@Api(description="sample data")*/
@RestController
@RequestMapping("/api/feedbacks")
@CrossOrigin(origins = "http://localhost:4200")
public class FeedbackRestController {
	
	private Logger log = LoggerFactory.getLogger(FeedbackRestController.class);

	@Autowired
	private IFeedbackService service;
	
	@Autowired
	private FeedbackUtil util;
	
	/**
	 * 1. Read JSON(Feedback) and convert to Object Format
	 *    Store data in Database. Return one Message.
	 */
	/*@ApiOperation("creating feedback data")*/
	@PostMapping
	public ResponseEntity<String> saveFeedback(
			@RequestBody Feedback feedback)
	{
		log.info("Entered into method with Feedback data to save");

		ResponseEntity<String> resp = null;
		try {

			log.info("About to call save Operation");

			Integer id = service.saveFeedback(feedback);
			log.debug("Feedback saved with id "+id);

			String body = "Feedback Send Succesfully";

			resp =  new ResponseEntity<String>(
					body,HttpStatus.CREATED); //201

			log.info("Sucess response constructed");
		} catch (Exception e) {
			log.error("Unable to save Feedback : problem is :"+e.getMessage());
			resp =  new ResponseEntity<String>(
					"Unable to Create Feedback", 
					HttpStatus.INTERNAL_SERVER_ERROR); //500
			e.printStackTrace();
		}

		log.info("About to Exist save method with Response");
		return resp;
	}
	
	/**
	 * 2. Fetch all rows from database using Service
	 *    Sort data using name, return as JSON, 
	 *    else String message no data found.
	 *    
	 */
	
	@GetMapping
	public ResponseEntity<?> getAllFeedback() {
		log.info("Entered into method to fetch Feedback data");
		ResponseEntity<?> resp = null ;
		try {

			log.info("About to call fetch feedback service");
			List<Feedback> list = service.getAllFeedbacks();
			if(list!=null && !list.isEmpty()) {
				log.info("Data is not empty=>"+list.size());
				list.sort((s1,s2)->s1.getPatientName().compareTo(s2.getPatientName())); 
				/* JDK 1.8s
				list = list.stream()
	 					.sorted((s1,s2)->s1.getName().compareTo(s2.getName()))
						.collect(Collectors.toList());
				 */
				resp = new ResponseEntity<List<Feedback>>(list, HttpStatus.OK);
			} else {
				log.info("No Appointment exist: size "+list.size());

				//Res = new ResponseEntity<>(HttpStatus.NO_CONTENT);
				resp = new ResponseEntity<String>(
						"No Appointment Found",
						HttpStatus.OK);
			}
		} catch (Exception e) {
			log.error("Unable to fetch feedback : problem is :"+e.getMessage());

			resp =  new ResponseEntity<String>(
					"Unable to Fetch Feedback", 
					HttpStatus.INTERNAL_SERVER_ERROR); //500
			e.printStackTrace();
		}
		log.info("About to Exist fetch all method with Response");
		return resp;
	}
	
	/***
	 * 3. Get one Appointment object based on ID (PathVariable). 
	 *   If Object exist then return Employee object 
	 *   else provide message(String).
	 */
	
	@GetMapping("/{id}")
	public ResponseEntity<?> getOneFeedback(
			@PathVariable Integer id
			) 
	{
		log.info("Entered into Get one Feedback method");
		ResponseEntity<?> resp = null;
		try {
			log.info("About to make service call to fetch one record");
			Optional<Feedback> opt =  service.getOneFeedback(id);
			if(opt.isPresent()) {
				log.info("Feedback exist=>"+id);
				resp = new ResponseEntity<Feedback>(opt.get(), HttpStatus.OK);
				//resp = ResponseEntity.ok(opt.get());
			} else {
				log.warn("Given Feedback id not exist=>"+id);
				resp = new ResponseEntity<String>(
						"Feedback '"+id+"' not exist", 
						HttpStatus.BAD_REQUEST);
			}
		} catch (Exception e) {
			log.error("Unable to process request fetch " + e.getMessage());
			resp = new ResponseEntity<String>(
					"Unable to process feedback fetch", 
					HttpStatus.INTERNAL_SERVER_ERROR);
			e.printStackTrace();
		}

		return resp;
	}
	
	/**
	 * 4. delete one row based on id (PathVariable)
	 *    First check given row exist or not?
	 *    if exist then call delete operation
	 *    else return  NO RECORD MESSAGE
	 *    
	 */
	
	@DeleteMapping("/{id}")
	public ResponseEntity<String> removeFeedback(
			@PathVariable Integer id
			)
	{

		log.info("Entered into delete method");
		ResponseEntity<String> resp = null;

		try {

			log.info("About to make service call for data check");
			boolean exist = service.isFeedbackExist(id);
			if(exist) {
				service.deleteFeedback(id);
				log.info("Feedback exist with given id and deleted=>"+id);
				resp = new ResponseEntity<String>(
						"Feedback  deleted",
						HttpStatus.OK);
			} else {
				log.warn("Given Feedback id not exist =>"+id);
				resp = new ResponseEntity<String>(
						"Feedback '"+id+"' not exist",
						HttpStatus.BAD_REQUEST);
			}
		} catch (Exception e) {
			log.error("Unable to perform Delete Operation =>" + e.getMessage());
			resp = new ResponseEntity<String>(
					"Unable to delete", 
					HttpStatus.INTERNAL_SERVER_ERROR);
			e.printStackTrace();
		}

		return resp;
	}
	
	/**
	 * 5. Update
	 */
	
	@PutMapping("/{id}")
	public ResponseEntity<String> updateFeedback(
			@PathVariable Integer id,
			@RequestBody Feedback feedback
			)
	{
		log.info("Entered into Update method");

		ResponseEntity<String> resp =null;

		try {
			log.info("About to check given id exist or not db");
			Optional<Feedback> opt =  service.getOneFeedback(id);
			if(opt.isPresent()) {
				log.info("Feedback present in database");
				Feedback actual = opt.get();
				util.mapToActualObject(actual,feedback);
				service.updateFeedback(actual);
				resp = new ResponseEntity<String>(
						"Feedback Updated", 
						//HttpStatus.RESET_CONTENT
						HttpStatus.OK
						);
				log.info("Feedback update done successfully");
			} else {
				log.info("Feedback not exist=>"+id);
				resp = new ResponseEntity<String>(
						"Feedback '"+id+"' not found", 
						//HttpStatus.RESET_CONTENT
						HttpStatus.BAD_REQUEST
						);
			}

		} catch (Exception e) {
			log.error("Unable to perform Update Operation=>" + e.getMessage() );
			resp = new ResponseEntity<String>(
					"Unable to process Update",
					HttpStatus.INTERNAL_SERVER_ERROR);
			e.printStackTrace();
		}

		return resp;
	}



}

