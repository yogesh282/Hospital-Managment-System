package hospital.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import hospital.model.Feedback;


public interface FeedbackRepository  extends JpaRepository<Feedback, Integer>
{

}
