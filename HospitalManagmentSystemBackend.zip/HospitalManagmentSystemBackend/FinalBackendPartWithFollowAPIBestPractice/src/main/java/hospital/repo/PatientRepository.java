package hospital.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import hospital.model.Patient;

public interface PatientRepository extends JpaRepository<Patient, Integer>
{

}