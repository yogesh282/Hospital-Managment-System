package hospital.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import hospital.model.Pay;


public interface PayRepository  extends JpaRepository<Pay, Integer>
{

}
