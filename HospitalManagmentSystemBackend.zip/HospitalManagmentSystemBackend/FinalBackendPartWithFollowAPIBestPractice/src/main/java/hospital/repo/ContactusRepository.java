package hospital.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import hospital.model.Contactus;


public interface ContactusRepository  extends JpaRepository<Contactus, Integer>
{

}
