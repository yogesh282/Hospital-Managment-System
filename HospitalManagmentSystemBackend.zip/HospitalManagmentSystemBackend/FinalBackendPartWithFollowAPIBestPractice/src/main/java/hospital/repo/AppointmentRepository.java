package hospital.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import hospital.model.Appointment;


public interface AppointmentRepository  extends JpaRepository<Appointment, Integer>
{

}

